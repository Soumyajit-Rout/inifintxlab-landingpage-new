# InfinitXLab Tech Institute Website

Animated institute website (Bhubaneswar): courses, trainers, upcoming batches, notifications,
enrollment, syllabus download (Google Drive), feedback, WhatsApp and contact.

## Structure
```
src/main/webapp/
  index.html, css/style.css, js/app.js   front end (animations)
  data/site.json                          courses, trainers, batches, notifications, reviews
  img/                                    trainer photos (add more here)
  submit.jsp     saves enrollments + feedback to CSV
  download.jsp   redirects to the Drive syllabus folder (link never shown on the page)
  admin.jsp      view/download enrollments (password protected)
  WEB-INF/config.properties   WhatsApp number, Drive URL, admin password, data folder
```

## Build
`mvn clean package` -> `target/infinitxlab.war`  (JDK 11+). Deploy to Tomcat `webapps/`, open `/infinitxlab/`.
Needs Tomcat 9 or 10 (JSP support). Release version is 1.1.0 - bump it for every `mvn deploy` (Nexus rejects re-deploying a release version).

## Edit content (no rebuild logic needed, just repackage)
- **Add a trainer photo:** put the file in `img/`, add `"photo":"img/name.jpg"` to that trainer in `data/site.json`.
- **Courses, fees, durations, batches, notifications:** edit `data/site.json`.
- **Student reviews:** approved feedback from `admin.jsp` -> add to `"feedback"` in `data/site.json`.
- **Drive syllabus:** `drive.folder` in `WEB-INF/config.properties` (folder must be "Anyone with the link").
  Per-course file: add `drive.aws-devops=<file link>` etc.
- **Admin:** `/infinitxlab/admin.jsp` - change `admin.password` first.
- Enrollment CSVs are stored in `$CATALINA_BASE/infinitxlab-data/` (or `data.dir`) and survive redeploys.
