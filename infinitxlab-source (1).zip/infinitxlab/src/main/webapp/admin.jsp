<%@ page contentType="text/html;charset=UTF-8" trimDirectiveWhitespaces="true" %>
<%@ include file="/WEB-INF/jspf/util.jspf" %>
<%
request.setCharacterEncoding("UTF-8");
java.util.Properties p=cfg(application.getRealPath("/WEB-INF/config.properties"));
String pw=p.getProperty("admin.password","change-me"), got=request.getParameter("pw");
boolean ok=got!=null&&pw!=null&&!pw.isEmpty()&&java.security.MessageDigest.isEqual(got.getBytes("UTF-8"),pw.getBytes("UTF-8"));
String f=request.getParameter("file");
if(ok&&f!=null&&f.matches("(enrollments|feedback|syllabus-downloads)\\.csv")){
  java.io.File file=new java.io.File(dataDir(p),f);
  if(file.exists()){ response.setContentType("text/csv;charset=UTF-8"); response.setHeader("Content-Disposition","attachment; filename="+f);
    java.nio.file.Files.copy(file.toPath(),response.getOutputStream()); return; }
}
%><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="robots" content="noindex"><title>InfinitXLab Admin</title>
<style>body{font:15px system-ui;background:#0b1020;color:#e8ecff;padding:24px}input,button{padding:10px;border-radius:8px;border:1px solid #334}button{background:#7c5cff;color:#fff;cursor:pointer}
table{border-collapse:collapse;margin:10px 0 28px;width:100%}td,th{border:1px solid #2a3355;padding:6px 10px;text-align:left;font-size:13px}a{color:#7fd1ff}</style></head><body>
<h2>InfinitXLab Admin</h2>
<% if(!ok){ %><form method="post"><input type="password" name="pw" placeholder="Admin password" autofocus> <button>Login</button></form>
<% if(got!=null){ %><p style="color:#ff8a8a">Wrong password</p><% } %>
<% }else{
  String[] files={"enrollments.csv","feedback.csv","syllabus-downloads.csv"};
  for(String n:files){ java.io.File file=new java.io.File(dataDir(p),n); %>
  <h3><%=n%> <form method="post" style="display:inline"><input type="hidden" name="pw" value="<%=h(got)%>"><input type="hidden" name="file" value="<%=n%>"><button>Download CSV</button></form></h3>
  <% if(!file.exists()){ %><p>No data yet.</p><% }else{
    java.util.List<String> lines=java.nio.file.Files.readAllLines(file.toPath(),java.nio.charset.StandardCharsets.UTF_8);
    int from=Math.max(1,lines.size()-100); %><table><% for(int i=lines.size()-1;i>=from;i--){ %><tr><td><%=h(lines.get(i).replace("\"\"","'"))%></td></tr><% } %></table>
  <% } } } %></body></html>
