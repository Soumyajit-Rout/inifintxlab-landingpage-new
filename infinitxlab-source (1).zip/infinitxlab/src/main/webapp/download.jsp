<%@ page contentType="text/html;charset=UTF-8" trimDirectiveWhitespaces="true" %>
<%@ include file="/WEB-INF/jspf/util.jspf" %>
<%
java.util.Properties p=cfg(application.getRealPath("/WEB-INF/config.properties"));
String c=request.getParameter("course"); if(c==null||!c.matches("[a-z0-9-]{1,40}")) c="";
String url=p.getProperty("drive."+c,p.getProperty("drive.folder",""));
try{ append(dataDir(p),"syllabus-downloads.csv","time,course",csv(new java.util.Date().toString())+","+csv(c)); }catch(Exception e){}
if(url.isEmpty()){ response.sendError(404); return; }
response.setHeader("Cache-Control","no-store");
response.sendRedirect(url);
%>
