(function(){
var $=function(s){return document.querySelector(s)},D=null;
function esc(s){return String(s==null?"":s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function wa(t){return"https://wa.me/"+D.whatsapp+"?text="+encodeURIComponent(t)}
fetch("data/site.json",{cache:"no-cache"}).then(function(r){return r.json()}).then(function(d){D=d;build();}).catch(function(){document.body.insertAdjacentHTML("afterbegin","<p style='padding:20px'>Unable to load site data.</p>")});

function build(){
 // notifications
 var n=D.notifications||[],i=0;
 $("#notes").innerHTML=n.map(function(x){return"<p><span class='pill'>"+esc(x.tag)+"</span>"+esc(x.text)+"</p>"}).join("");
 $("#bellN").textContent=n.length; 
 function tick(){if(!n.length)return;$("#tkTag").textContent=n[i].tag;var t=$("#tkText");t.style.animation="none";t.offsetWidth;t.style.animation="";t.textContent=n[i].text;i=(i+1)%n.length}
 tick();setInterval(tick,5000);
 $("#bell").onclick=function(){$("#panel").classList.toggle("on");$("#bellN").style.display="none"};
 // links
 var wm="Hi InfinitXLab, I want to know more about your courses.";
 ["#waHero","#waEnroll","#waContact","#waFab"].forEach(function(s){$(s).href=wa(wm)});
 $("#tel1").textContent=D.phone;$("#tel1").href="tel:+91"+D.phone;$("#tel2").textContent=D.phone2;$("#tel2").href="tel:+91"+D.phone2;
 $("#mail").textContent=D.email;$("#mail").href="mailto:"+D.email;$("#yr").textContent=new Date().getFullYear();
 // courses
 $("#courseGrid").innerHTML=D.courses.map(function(c){return"<article class='card rv tilt'><div class='ico'>"+c.icon+"</div><h3>"+esc(c.title)+"</h3>"+
  "<div class='meta'><span>⏱ "+esc(c.duration)+"</span><span>💰 "+esc(c.fee)+"</span><span>"+esc(c.mode)+"</span></div>"+
  "<ul>"+c.topics.map(function(t){return"<li>"+esc(t)+"</li>"}).join("")+"</ul><p class='tr'>Trainer: "+esc(c.trainer)+"</p>"+
  "<div class='row' style='margin-top:12px'><a class='btn go' href='#enroll' data-c='"+esc(c.title)+"'>Enroll</a>"+
  "<a class='btn ghost' href='download.jsp?course="+esc(c.id)+"' target='_blank' rel='noopener'>⬇ Syllabus</a>"+
  "<a class='btn wa' target='_blank' rel='noopener' href='"+wa("Hi, I am interested in "+c.title)+"'>WhatsApp</a></div></article>"}).join("");
 var opts=D.courses.map(function(c){return"<option>"+esc(c.title)+"</option>"}).join("");
 $("#courseSel").innerHTML=opts;$("#fbCourse").innerHTML=opts;
 document.querySelectorAll("[data-c]").forEach(function(a){a.onclick=function(){$("#courseSel").value=a.dataset.c}});
 // faculty
 $("#team").innerHTML=D.faculty.map(function(f){var ini=f.name.split(" ").map(function(w){return w[0]}).slice(0,2).join("");
  return"<article class='tm rv'><div class='ph'>"+(f.photo?"<img src='"+esc(f.photo)+"' alt='"+esc(f.name)+"' loading='lazy'>":ini)+"</div><div class='b'><h3>"+esc(f.name)+"</h3><div class='rl'>"+esc(f.role)+"</div>"+
  "<span class='xp'>"+esc(f.exp)+" years experience</span>"+(f.tag?" <span class='xp'>"+esc(f.tag)+"</span>":"")+"<p class='mute' style='font-size:.88rem;margin-top:10px'>"+esc(f.bio)+"</p></div></article>"}).join("");
 // batches
 $("#batchBody").innerHTML=D.batches.map(function(b){return"<tr><td><b>"+esc(b.course)+"</b></td><td>"+esc(b.start)+"</td><td>"+esc(b.time)+"</td><td>"+esc(b.mode)+"</td><td>"+esc(b.seats)+"</td><td><a class='btn go' style='padding:8px 14px' href='#enroll'>Reserve</a></td></tr>"}).join("");
 // feedback
 var fb=D.feedback||[];$("#fbList").innerHTML=fb.length?fb.map(function(f){return"<div class='card rv'><div class='stars'>"+"★".repeat(f.rating||5)+"</div><p class='q'>“"+esc(f.message)+"”</p><p><b>"+esc(f.name)+"</b><br><span class='tr'>"+esc(f.course)+"</span></p></div>"}).join(""):"<p class='mute'>Student reviews will appear here. Be the first to share your experience below.</p>";
 forms();effects();
}

function forms(){
 [["#enrollForm","#enrollMsg","enroll"],["#fbForm","#fbMsg","fb"]].forEach(function(x){
  var f=$(x[0]),m=$(x[1]);
  f.onsubmit=function(e){e.preventDefault();m.className="msg";m.textContent="Sending...";
   var fd=new FormData(f),body=new URLSearchParams(fd),name=fd.get("name")||"";
   fetch("submit.jsp",{method:"POST",body:body}).then(function(r){return r.json().then(function(j){return{ok:r.ok&&j.ok,j:j}})}).then(function(r){
    if(!r.ok){m.className="msg er";m.textContent=(r.j&&r.j.error)||"Could not submit. Please try again.";return}
    m.className="msg ok";f.reset();
    if(x[2]=="enroll"){m.innerHTML="Thank you, "+esc(name)+"! We will contact you soon. <a href='"+wa("Hi, I just enrolled: "+name+" - "+fd.get("course"))+"' target='_blank' rel='noopener' style='text-decoration:underline'>Confirm on WhatsApp</a>"}
    else m.textContent="Thank you for your feedback!";
   }).catch(function(){m.className="msg er";m.innerHTML="Server unavailable. <a href='"+wa("Hi, I want to enroll. Name: "+name+", Phone: "+(fd.get("phone")||"")+", Course: "+(fd.get("course")||""))+"' target='_blank' rel='noopener' style='text-decoration:underline'>Send via WhatsApp instead</a>"});
  }});
}

function effects(){
 $("#burger").onclick=function(){$("#nav").classList.toggle("on")};
 document.querySelectorAll("#nav a").forEach(function(a){a.onclick=function(){$("#nav").classList.remove("on")}});
 // reveal + counters
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}})},{threshold:.12});
 document.querySelectorAll(".rv").forEach(function(el,i){el.style.transitionDelay=(i%4)*70+"ms";io.observe(el)});
 var co=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;co.unobserve(e.target);var t=+e.target.dataset.n,s=e.target.dataset.s||"",st=performance.now();
  (function f(now){var p=Math.min((now-st)/1400,1);e.target.textContent=Math.round(t*(1-Math.pow(1-p,3)))+s;if(p<1)requestAnimationFrame(f)})(st)})},{threshold:.6});
 document.querySelectorAll("[data-n]").forEach(function(el){co.observe(el)});
 // rotating headline + reel progress
 var lines=["Excel in Cloud.","Excel in DevOps.","Excel in AI / ML.","Excel in Automation."],k=0,bars=document.querySelectorAll("#reel i");
 function step(){var sc=$("#scene");sc.innerHTML="<span>"+lines[k]+"</span>";bars.forEach(function(b,j){b.className=j<k?"done":j==k?"on":""});k=(k+1)%lines.length}
 step();setInterval(step,2400);
 // cursor glow + tilt
 var g=$("#glow");document.addEventListener("pointermove",function(e){g.style.left=e.clientX+"px";g.style.top=e.clientY+"px"});
 document.querySelectorAll(".tilt").forEach(function(c){c.addEventListener("pointermove",function(e){var r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transform="perspective(700px) rotateY("+x*7+"deg) rotateX("+-y*7+"deg) translateY(-4px)"});
  c.addEventListener("pointerleave",function(){c.style.transform=""})});
 network();
}

function network(){
 var cv=$("#net"),x=cv.getContext("2d"),W,H,P=[],M={x:-999,y:-999};
 function rs(){W=cv.width=cv.offsetWidth;H=cv.height=cv.offsetHeight;P=[];var n=Math.min(90,Math.floor(W*H/14000));for(var i=0;i<n;i++)P.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.5,vy:(Math.random()-.5)*.5})}
 rs();addEventListener("resize",rs);cv.parentNode.addEventListener("pointermove",function(e){var r=cv.getBoundingClientRect();M.x=e.clientX-r.left;M.y=e.clientY-r.top});
 (function draw(){x.clearRect(0,0,W,H);
  for(var i=0;i<P.length;i++){var p=P[i];p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
   var dm=Math.hypot(p.x-M.x,p.y-M.y);if(dm<140){p.x+=(p.x-M.x)*.01;p.y+=(p.y-M.y)*.01}
   x.fillStyle="rgba(124,92,255,.85)";x.beginPath();x.arc(p.x,p.y,2,0,6.3);x.fill();
   for(var j=i+1;j<P.length;j++){var q=P[j],d=Math.hypot(p.x-q.x,p.y-q.y);if(d<130){x.strokeStyle="rgba(34,211,238,"+(1-d/130)*.4+")";x.beginPath();x.moveTo(p.x,p.y);x.lineTo(q.x,q.y);x.stroke()}}}
  requestAnimationFrame(draw)})();
}
})();
