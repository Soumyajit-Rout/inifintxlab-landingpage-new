<%@ page contentType="application/json;charset=UTF-8" trimDirectiveWhitespaces="true" %>
<%@ include file="/WEB-INF/jspf/util.jspf" %>
<%
request.setCharacterEncoding("UTF-8");
String type=request.getParameter("type"); String now=new java.util.Date().toString();
try{
  if(!"POST".equals(request.getMethod())){ response.setStatus(405); out.print("{\"ok\":false}"); return; }
  if(request.getParameter("website")!=null&&!request.getParameter("website").isEmpty()){ out.print("{\"ok\":true}"); return; } // honeypot
  String name=request.getParameter("name"), phone=request.getParameter("phone"); if(phone==null) phone="";
  String digits=phone.replaceAll("\\D","");
  if(name==null||name.trim().length()<2){ response.setStatus(400); out.print("{\"ok\":false,\"error\":\"Please enter your name\"}"); return; }
  java.io.File dir=dataDir(cfg(application.getRealPath("/WEB-INF/config.properties")));
  if("feedback".equals(type)){
    append(dir,"feedback.csv","time,name,course,rating,message",csv(now)+","+csv(name)+","+csv(request.getParameter("course"))+","+csv(request.getParameter("rating"))+","+csv(request.getParameter("message")));
  }else{
    if(digits.length()<10||digits.length()>13){ response.setStatus(400); out.print("{\"ok\":false,\"error\":\"Enter a valid phone number\"}"); return; }
    append(dir,"enrollments.csv","time,name,phone,email,course,mode,message",csv(now)+","+csv(name)+","+csv(phone)+","+csv(request.getParameter("email"))+","+csv(request.getParameter("course"))+","+csv(request.getParameter("mode"))+","+csv(request.getParameter("message")));
  }
  out.print("{\"ok\":true}");
}catch(Exception e){ response.setStatus(500); out.print("{\"ok\":false,\"error\":\"Server error\"}"); }
%>
